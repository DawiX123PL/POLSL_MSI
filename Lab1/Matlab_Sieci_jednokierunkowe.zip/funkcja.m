function [Y] = funkcja(X)
Y=sin(X);
end

